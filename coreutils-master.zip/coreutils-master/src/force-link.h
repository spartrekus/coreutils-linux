extern int force_linkat (int, char const *, int, char const *, int, bool, int);
extern int force_symlinkat (char const *, int, char const *, bool, int);
