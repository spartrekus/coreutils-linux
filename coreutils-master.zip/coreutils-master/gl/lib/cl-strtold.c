#define LONG 1
#include "cl-strtod.c"
